export class Venue
{
    id: number;
    venueID : string;
   stadiumName : string;
   city : string;
   country : string;
   capacity : number;
   surface : string;
  



    constructor( Id:number,VenueID:string,StadiumName: string, City: string, Country: string, Capacity: number, Surface: string, ){
        this.id = Id;
        this.venueID = VenueID;
   this.stadiumName = StadiumName;
   this.city = City;
   this.country = Country;
   this.capacity = Capacity;
   this.surface = Surface;
   
    }
}