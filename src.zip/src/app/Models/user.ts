export class User 
{
     
     username:string; 
     password: string; 
    
     
     constructor( Username: string, Password: string, )
     { 
        
         this.username= Username;
         this.password= Password;

    }
}
