export class Player{
    id: number;
    playerID : string;
    playerName :string;
    playerCountry : string;
    playerDOB : string;
    playerRanking : number;
    handed : string;




  constructor( Id:number, PlayerID: string, PlayerName: string, PlayerCountry: string, PlayerDOB: string,PlayerRanking : number ,Handed: string){
        this.id = Id;
        this.playerID = PlayerID;
        this.playerName = PlayerName;
        this.playerCountry =PlayerCountry;
        this.playerDOB= PlayerDOB;
        this.playerRanking= PlayerRanking;
        this.handed = Handed;
    }
    
    
    }