export class Tournament{
    id: number;
tournamentID : string;
tournamentName : string;
venueID : string;
startDOT : string;
endDOT : string;
winnerID : string;
runnerUpID : string;
playersCount : number;
matchCount : number;

constructor( Id:number,TournamentID: string,TournamentName:string, VenueID: string, StartDOT: string, EndDOT: string, WinnerID: string, 
    RunnerupID: string, PlayersCount: number , MatchCount : number){
        this.id = Id;
    this.tournamentID = TournamentID;
    this.tournamentName = TournamentName;
    this.venueID = VenueID;
    this.startDOT =StartDOT;
    this.endDOT= EndDOT;
    this.winnerID= WinnerID;
    this.runnerUpID= RunnerupID;
    this.playersCount = PlayersCount;
    this.matchCount = MatchCount;
}

}