export class Match{
    id: number;
    tournamentID : string;
    matchID : string;
    dOM : string;
    typeOfMatch : string;
    playerOneID : string;
    playerTwoID : string;
    scoreCard : string;
    matchWinnerID : string;

    constructor(Id: number, TournamentID: string, MatchID: string,DOM:string, TypeOfMatch: string, PlayerOneID: string, PlayerTwoID: string,
        ScoreCard :string, MatchwinnerID:string){
        this.id = Id;
        this.tournamentID = TournamentID;
        this.matchID = MatchID;
        this.dOM=DOM;
        this.typeOfMatch= TypeOfMatch;
        this.playerOneID= PlayerOneID;
        this.playerTwoID = PlayerTwoID;
        this.scoreCard = ScoreCard;
        this.matchWinnerID = MatchwinnerID;
    }

    
    
    }