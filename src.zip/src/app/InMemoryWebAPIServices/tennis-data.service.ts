import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Match } from '../Models/match';
import {Player} from '../Models/player';
import { Venue } from '../Models/venue';
import { Tournament } from '../Models/tournament';
import {User} from '../Models/user';


@Injectable({
    providedIn: 'root'
  })
 export class TennisDataService implements InMemoryDbService{

    constructor(){}

    createDb(){
        //write fake data here

        let user = [
            new User('Iamadmin', 'Sports123')
          ];
         
      
         let player = [new Player(null,null,null,null,null,null,null)];

        let venues = [
        new Venue(1,'V1','Arthur Ashe Stadium','New York City','United States',23771,'HARD'),
        new Venue(2,'V2','O2 Arena','London','United Kingdom',17500,'HARD'),
        new Venue(3,'V3','Stade Roland Garros','Paris','France',15225,'CLAY'),
        new Venue(4,'V4','Am Rothenbaum','Hamburg','Germany',13200,'CLAY'),
        new Venue(5,'V5','Wimbledon Centre Court','London','United Kingdom',14979,'GRASS'),
        new Venue(6,'V6','Gerry Weber Stadion','Halle','Germany',11500,'GRASS'),
        ];

        // let tournaments = [
        //     new Tournament(1,'T1','V1','01/01/2020', '25/01/2020')
            
        //     ];

        let players = [
            new Player(1,'P1','Ankush','India','19/04/1996',4,'Right Handed'),
            new Player(2,'P2','Pushpraj','India','10/04/1996',2,'Right Handed'),
            new Player(3,'P3','Siddharth','Australia','05/01/1997',3,'Left Handed'),
            new Player(4,'P4','Abhishek','Spain','27/01/1997',1,'Left Handed'),
            new Player(5,'P5','Ritwik','Africa','12/02/1996',5,'Right Handed'),
            new Player(6,'P6','Ayuss','India','12/10/1996',6,'Right Handed'),
            new Player(7,'P7','Aman','India','01/04/1996',7,'Right Handed'),
            new Player(8,'P8','Daddu','India','19/01/1993',8,'left Handed'),

        ];

        let matches = [
            new Match(1,'T1','M1','02/01/2020','QF','P1','P3','2-6 7-5 6-2','P1'),
            new Match(2,'T1','M2','02/01/2020','QF','P2','P7','5-7 7-5 4-6','P7'),
            new Match(3,'T1','M3','05/01/2020','QF','P4','P6','2-6 7-5 6-2','P4'),
            new Match(4,'T1','M4','05/01/2020','QF','P5','P8','2-6 7-5 6-2','P8'),
            new Match(5,'T1','M5','15/01/2020','SF','P1','P7','2-6 7-5 6-2','P1'),
            new Match(6,'T1','M6','16/01/2020','SF','P4','P8','2-6 7-5 6-2','P4'),
            new Match(7,'T1','M7','24/01/2020','F','P1','P4','2-6 7-5 6-2','P1'),
        ];

        let tournaments = [
          new Tournament(1,'T1','World Open', 'V3', '01/01/2020', '25/01/2020', 'P1', 'P4', 8, 7)  
        ];







        return {user, venues, players, matches, tournaments};
    }
    
 } 