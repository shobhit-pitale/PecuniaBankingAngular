import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-masterpage',
  templateUrl: './masterPage.component.html',
  styleUrls: ['./masterPage.component.scss']
})
export class MasterPageComponent {
  title = 'Tennis';
}
