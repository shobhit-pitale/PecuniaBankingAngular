import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Tournament } from '../Models/tournament'
import { Match } from '../Models/match'
import { TennisDataService } from 'src/app/InMemoryWebAPIServices/tennis-data.service';
import { Player } from '../Models/player';
import { PlayersService } from '../Services/players.service';
import { MatchesService } from 'src/app/Services/matches.service';
import { ActivatedRoute } from '@angular/router';
import { TournamentsService } from '../Services/tournaments.service'
import { rendererTypeName } from '@angular/compiler';

@Component({
  selector: 'app-step2CreateTournament',
  templateUrl: './step2CreateTournament.component.html',
  styleUrls: ['./step2CreateTournament.component.scss']

})
export class Step2CreateTournamentComponent extends TennisDataService implements OnInit {


  count: number = 8;
  players: Player[] = [];
  matches: Match[] = [];
  temp: Player[] = [];
  disable: boolean = false;
  step_2: boolean = true;
  step_3: boolean = false;
  disabledReason: number;
  a: number[] = [];
  ta: number = 0;
  b: number[] = [];
  i: number;
  j: number;
  matchesPlayers: Player[] = [];
  l: number[] = [];
  
  p1: Player = new Player(
    0,
    null,
    null,
    null,
    null,
    0,
    null,
  );

  id: number = -1;
  tournament: Tournament = {
    id: 0,
    tournamentID: "",
    tournamentName: "",
    venueID: "",
    startDOT: "",
    endDOT: "",
    winnerID: "",
    runnerUpID: "",
    playersCount: 0,
    matchCount: 0,
  };
  playCount: number = 0;
  selected: any;
  colorApply: boolean[] = [];

  constructor(private playersService: PlayersService, private matchesService: MatchesService, private route: ActivatedRoute, private tournamentservice: TournamentsService
    , private router: Router) {
    super();
  }





  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.id = +params.get('id');
      //   console.log(this.id);
    }, (error) => { console.log(error); });

    this.tournamentservice.GetTournamentByID(this.id).subscribe(response1 => {
      this.tournament = response1[0];

      //    console.log("2nd page")

      //  console.log(this.tournament);




      this.playersService.GetAllPlayers().subscribe((response) => {
        //    console.log(response);
        this.players = response;
        var length = response.length;
        for (this.i = 0; this.i < length; this.i++) {
          this.a.push(-1);
        }
        for (this.i = 0; this.i < length; this.i++) {
          this.colorApply.push(false);
        }
      },
        (error) => {
          console.log(error);

        });
    }, (error) => { console.log(error); });

  }







  onbuttonClick(index: number) {

    localStorage.setItem('key', this.tournament.tournamentID);
    this.disabledReason = index;

    this.SelectedPlayers(this.disabledReason)
    //   console.log(this.a);
    //    console.log(this.colorApply);
    if (this.colorApply[index] == false)
      this.colorApply[index] = true;
    else
      this.colorApply[index] = false;

    //    console.log(this.colorApply);
  }


  isActive(index) {
    if (this.colorApply[index] == true) {
      //       console.log(this.colorApply[index]==true);
      return { 'highlight': true };
    }
    else
      return false;
  }


  SelectedPlayers(value: number) {


    for (this.i = 0; this.i < this.a.length; this.i++) {
      if (this.a.indexOf(value) != -1) {
        this.a[value] = -1;
        break;
      }


      if (this.a[this.i] == -1) {
        this.a[value] = value;
        break;
      }

    }
    this.playCount = 0;
    for (this.j = 0; this.j < this.a.length; this.j++) {

      if (this.a[this.j] != -1) {
        this.playCount++;

      }
    }
    //  console.log(this.playCount);

    // console.log(this.tournament.playersCount);
    if (this.playCount == this.tournament.playersCount) {
      this.disable = true;
    }
    else {
      this.disable = false;
    }

  }

  createMatches() {
    let pa: number;

    for (this.ta = 0; this.ta < this.a.length; this.ta++) {
      if (this.a[this.ta] != -1) {
        this.playersService.GetPlayerByID(this.ta + 1).subscribe((response) => {

          this.p1 = response[0];

          this.matchesPlayers.push(this.p1);
          if (this.matchesPlayers.length == this.tournament.playersCount) {
            for (pa = 0; pa < (this.tournament.playersCount) / 2; pa++) {

              let matchfor: Match = {
                id: 0,
                tournamentID: "",
                typeOfMatch: "",
                scoreCard: "",
                playerOneID: "",
                playerTwoID: "",
                matchWinnerID: "",
                dOM: "",
                matchID: ""

              };

              
              matchfor.tournamentID = this.tournament.tournamentID.toString();
              matchfor.typeOfMatch = "1st Round";
              matchfor.scoreCard = "Yet to decide";
              matchfor.playerOneID = this.matchesPlayers[pa].playerID;
              matchfor.dOM = this.tournament.startDOT;
              matchfor.playerTwoID = this.matchesPlayers[this.matchesPlayers.length - pa - 1].playerID;
              matchfor.matchWinnerID = "Match not played yet";
              this.AddMatch(matchfor);
             

              

            }
          }


        },
          (error) => { console.log(error); },



        );
      }

    }
    this.router.navigate(['/match']);
  }



  AddMatch(MA: Match) {

   
    
    MA.id = this.count;

    
    this.matchesService.AddMatch(MA).subscribe((addResponse) => {
      //console.log(addResponse);
      console.log(MA);
      this.matches.push(MA);
      console.log(this.matches)
    },
      (error) => {
        console.log(error);

      });
    this.count++;

  }
  

}



