import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../Models/user';

@Injectable({
  providedIn: 'root'
})
export class UserAccountService
{
    currentUser: User;
    isLoggedIn: boolean;
    currentUserType: string;

    constructor(private httpclient:HttpClient)
    {
      this.currentUser= new User(null,null);
      this.isLoggedIn= false;
      this.currentUserType=null;

    }

    authenticate(username: string, password:string): Observable<any>
    {
      if(username=="Iamadmin"){
        return this.httpclient.get(`/api/user?password=${password}`);
      }
      else{
        return this.httpclient.get(`/api/user?username=${username}&password=${password}`);
      }
      

    }
}