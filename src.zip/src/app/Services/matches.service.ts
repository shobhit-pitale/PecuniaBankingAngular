import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Match } from '../Models/match';

@Injectable({
  providedIn: 'root'
})
export class MatchesService
{
  constructor(private httpClient: HttpClient)
  {
  }

  AddMatch(match: Match): Observable<boolean>
  {
   
    match.matchID = this.uuidv4();
    return this.httpClient.post<boolean>(`/api/matches`, match);
  }

  UpdateMatch(match: Match): Observable<boolean>
  {
    
    return this.httpClient.put<boolean>(`/api/matches`, match);
  }

  DeleteMatch(matchID: string, id: number): Observable<boolean>
  {
    return this.httpClient.delete<boolean>(`/api/matches/${id}`);
  }

  GetAllMatches(): Observable<Match[]>
  {
    return this.httpClient.get<Match[]>(`/api/matches`);
  }

  GetMatchByID(ID: number): Observable<Match>
  {
    return this.httpClient.get<Match>(`/api/matches?id=${ID}`);
  }

  GetMatchByMatchID(MatchID: string): Observable<Match>
  {
    return this.httpClient.get<Match>(`/api/matches?matchID=${MatchID}`);
  }
  GetMatchesByTournamentID(TournamentID: string): Observable<Match[]>
  {
    return this.httpClient.get<Match[]>(`/api/matches?tournamentID=${TournamentID}`);
  }

  
  uuidv4()
  {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c)
    {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}
