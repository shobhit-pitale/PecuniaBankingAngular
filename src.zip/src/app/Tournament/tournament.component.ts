import {Component, OnInit} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {Venue} from '../Models/venue';
import {Tournament} from '../Models/tournament';
import {TennisDataService} from '../InMemoryWebAPIServices/tennis-data.service'
import {VenuesService} from '../Services/venues.service'
import {TennisComponentBase} from '../Tennis-component'
import { BoundText } from '@angular/compiler/src/render3/r3_ast';
import * as $ from "jquery";
import { TournamentsService } from '../Services/tournaments.service';
import * as globe from '../global'

@Component({
    selector: 'app-tournament',
    templateUrl: './tournament.component.html',
    styleUrls: ['./tournament.component.scss']

})
export class TournamentComponent implements OnInit

{
    
    
    
    
    
    venues: Venue[]=[];
    newTournament: FormGroup;
    newTournamentErrorMessages:any;
    disable : boolean = false;
    passTID:number;
    tournament: Tournament[] = [];
    
    constructor(private venuesService:VenuesService, private tournamentsService : TournamentsService , private router:Router){
       
       this.newTournament = new FormGroup({
        tournamentName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z ]*$/), Validators.minLength(2), Validators.maxLength(40)]),


        playersCount : new FormControl('', Validators.required),
        venueID: new FormControl('', Validators.required),
        startDOT: new FormControl(new Date().toLocaleDateString(), Validators.required)
       });

      
      

    //    Initially 4 will be selected.
       this.newTournament.patchValue({playersCount:'4', venueID: 'V1' });

       this.newTournamentErrorMessages = {
        tournamentName: { required: "Tournament name can't be blank", minlength: "Tournament name should contain at least 2 characters", maxlength: "Tournament name can't be longer than 40 characters", pattern: "Tournament name contains invalid characters."},
        startDOT:{required: "Date can't be blank"}
       };
    }
    

    currentDate() {
        const currentDate = new Date();
        return currentDate.toISOString().substring(0,10);
      }
    
    ngOnInit(){   
        // Fetch all venues and bind to the drop Box.
        this.venuesService.GetAllVenues().subscribe((response)=>{
            console.log(response);
            this.venues = response;
        },(error)=>{
            console.log(error);
            });

            this.tournamentsService.GetAllTournament().subscribe((response)=>{
                this.passTID = response[response.length-1].id+1;
                console.log(this.passTID);
        
                }, (error)=>{console.log(error);});

    
     

        function Ctrl($scope)
        {
        $scope.date = new Date().toLocaleDateString;

        }


        $(function() {
            var dtToday = new Date();
    
            var month = dtToday.getMonth() + 1;
            var day = dtToday.getDate();
            console.log(day);

            var year = dtToday.getFullYear();
            if (month < 10)
              var month1 = '0' + month.toString();
            if (day < 10)
                var day1 = '0' + day.toString();
            if(day>9)
                var day1 = day.toString();
            if(month>9)
                var month1 = month.toString();

    
            var maxDate = year + '-' + month1 + '-' + day1   ;
            console.log(day1);
    
            $('#startDOT').attr('min', maxDate);
            $('#startDOT').val(maxDate);
           
        });
    
       
        
    }
    
    //  OngamerClick(){
    //     this.router.navigate(['/step2CreateTournament/'], { queryParams: { id: this.passTID } }); 
    //  }

    onAddTournamentClick(event)
{
  this.newTournament["submitted"] = true;
  if (this.newTournament.valid)
  {
      console.log(this.newTournament.valid);
    this.disable = true;
    var tournament: Tournament = this.newTournament.value;
    tournament.matchCount = tournament.playersCount -1;
    tournament.tournamentID = "T6";
    // globe.matchCount =  tournament.matchCount;
    // globe.playersCount = tournament.playersCount;
    // globe.startDOT = tournament.startDOT;
    // globe.venueID = tournament.venueID;
    // globe.tournamentName = tournament.tournamentName;


    // let newDate = new Date(tournament.startDOT);
    // console.log(newDate);
    
     let endDate = new Date(tournament.startDOT);

    //  endDate.setMonth(endDate.getMonth + 1)
    // endDate.
    // console.log(tournament);


    this.tournamentsService.AddTournament(tournament).subscribe((addResponse) =>
    {
        console.log(addResponse);
      
        
        this.newTournament.reset();

        this.newTournament.patchValue({playersCount:'4', venueID: 'V1' });
     

      $("#btnAddTCancel").trigger("click");
      this.disable = false;
      console.log("Events", event);
      $("#gamer").trigger("click");
    
      


    

      

    });
  
   
}
  else
  {
    //super.getFormGroupErrors(this.newTournament);
  }
}

}
