import { Component, OnInit } from '@angular/core';
import { Tournament } from '../Models/tournament'
import { Match } from '../Models/match'
import { TennisDataService } from 'src/app/InMemoryWebAPIServices/tennis-data.service';
import { Player } from '../Models/player';
import { PlayersService } from '../Services/players.service';
import { MatchesService } from 'src/app/Services/matches.service';
import { ActivatedRoute } from '@angular/router';
import { TournamentsService } from '../Services/tournaments.service'
import { rendererTypeName } from '@angular/compiler';


@Component({
  selector: 'app-match',
  templateUrl: './match.component.html',
  styleUrls: ['./match.component.scss']
})
export class MatchComponent implements OnInit {
  matches: Match[] = [];

  constructor(private playersService: PlayersService, private matchesService: MatchesService, private route: ActivatedRoute, private tournamentservice: TournamentsService) {
    ; }

  ngOnInit() {
    var ID = localStorage.getItem('key');
    console.log(ID)
    this.matchesService.GetMatchesByTournamentID(ID).subscribe(reponse => {

      setTimeout(()=>this.matches = reponse,5000);
      console.log(this.matches);
    });

    




  }

}
