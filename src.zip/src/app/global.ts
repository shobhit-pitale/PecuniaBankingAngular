import { Injectable } from "@angular/core";

@Injectable()
export class Globals {
  TID : number = -1;



  tournamentName : string = '';
  venueID : string = '';
  startDOT : string='';

  playersCount : number=-1;
  matchCount : number=-1;
}
