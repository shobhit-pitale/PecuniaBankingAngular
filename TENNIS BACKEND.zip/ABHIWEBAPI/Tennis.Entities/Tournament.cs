﻿using System;

namespace Tennis.Entities
{
    public class Tournament
    {
    }
}
