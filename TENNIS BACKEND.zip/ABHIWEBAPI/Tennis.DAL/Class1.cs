﻿using System;

namespace Tennis.DAL
{
    public class Class1
    {
    }
}
