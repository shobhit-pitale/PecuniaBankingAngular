﻿using System;

namespace Tennis.BL
{
    public class Class1
    {
    }
}
